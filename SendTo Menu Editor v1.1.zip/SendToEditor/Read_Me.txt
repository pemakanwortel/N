Author: BlueLife , Velociraptor
www.sordum.org


%%%%%%%%%%%%%%%%%%%%% SendTo Menu Editor v1.1 (July 28, 2018) %%%%%%%%%%%%%%%%%%%%%

FiXED - in standard user Send to folder of the Standard users cannot be selected

%%%%%%%%%%%%%%%%%%%%% SendTo Menu Editor v1.0 (June 28, 2018) %%%%%%%%%%%%%%%%%%%%%

First release
Send To Menu Editor� is a portable freeware which helps users manage the shortcuts present in the 
Windows �Send To� Menu.